@echo off
python Feer.py
pause
