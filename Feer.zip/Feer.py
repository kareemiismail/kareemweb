import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk, ImageDraw
import os, json, time

# =========================
# FILE SYSTEM
# =========================
FEER_FILES = os.path.join(os.path.expanduser("~"), "Documents", "Feer Files")
os.makedirs(FEER_FILES, exist_ok=True)

SETTINGS_FILE = "feer_settings.json"
USERS_FILE = "feer_users.json"

settings = json.load(open(SETTINGS_FILE)) if os.path.exists(SETTINGS_FILE) else {}
users = json.load(open(USERS_FILE)) if os.path.exists(USERS_FILE) else []

def save_settings():
    json.dump(settings, open(SETTINGS_FILE, "w"))

def save_users():
    json.dump(users, open(USERS_FILE, "w"))

current_user = "Guest"

# =========================
# ROOT WINDOW
# =========================
root = tk.Tk()
root.overrideredirect(True)

W, H = root.winfo_screenwidth(), root.winfo_screenheight()
root.geometry(f"{W}x{H}+0+0")
root.bind("<Escape>", lambda e: root.destroy())

# =========================
# BOOT SCREEN
# =========================
boot = tk.Frame(root, bg="black")
boot.place(x=0, y=0, width=W, height=H)

boot_logo_img = Image.open("Feer.png").resize((220, 220))
boot_logo = ImageTk.PhotoImage(boot_logo_img)

tk.Label(boot, image=boot_logo, bg="black").pack(expand=True)

bar_bg = tk.Frame(boot, bg="#333", width=420, height=18)
bar_bg.pack(pady=40)

bar = tk.Frame(bar_bg, bg="#00ff88", height=18, width=0)
bar.place(x=0, y=0)

def boot_load(p=0):
    bar.config(width=int((p/100)*420))
    if p < 100:
        root.after(25, lambda: boot_load(p+2))
    else:
        boot.destroy()
        login_screen()

boot_load()

# =========================
# LOGIN SCREEN
# =========================
login = tk.Frame(root, bg="#1e1e2f")

def login_screen():
    login.place(x=0, y=0, width=W, height=H)

    tk.Label(login, text="Welcome to Feer",
             font=("Segoe UI", 24),
             fg="white", bg="#1e1e2f").pack(pady=30)

    lb = tk.Listbox(login, width=30, height=5)
    for u in users:
        lb.insert("end", u)
    lb.pack(pady=10)

    entry = tk.Entry(login, width=30)
    entry.pack(pady=5)

    def create_user():
        if entry.get() and entry.get() not in users:
            users.append(entry.get())
            save_users()
            lb.insert("end", entry.get())
            entry.delete(0, "end")

    def login_user(name):
        global current_user
        current_user = name
        login.destroy()
        start_desktop()

    tk.Button(login, text="Create User", command=create_user).pack()
    tk.Button(login, text="Login",
              command=lambda: login_user(users[lb.curselection()[0]])
              if lb.curselection() else None).pack()
    tk.Button(login, text="Guest",
              command=lambda: login_user("Guest")).pack()

# =========================
# DESKTOP
# =========================
desktop = tk.Frame(root)
desktop.place(x=0, y=0, width=W, height=H)

bg_label = tk.Label(desktop)
bg_label.place(x=0, y=0, width=W, height=H)

def load_wallpaper():
    if "wallpaper" in settings and os.path.exists(settings["wallpaper"]):
        img = Image.open(settings["wallpaper"]).resize((W, H))
        bg = ImageTk.PhotoImage(img)
        bg_label.config(image=bg)
        bg_label.image = bg
    else:
        bg_label.config(bg="#2b2b40")

load_wallpaper()

# =========================
# TASKBAR
# =========================
taskbar = tk.Frame(desktop, bg="#111", height=40)
taskbar.pack(side="bottom", fill="x")

start_logo_img = Image.open("Feer.png").resize((28, 28))
start_logo = ImageTk.PhotoImage(start_logo_img)

task_area = tk.Frame(taskbar, bg="#111")
task_area.pack(side="left")

clock = tk.Label(taskbar, fg="white", bg="#111")
clock.pack(side="right", padx=10)

def update_clock():
    clock.config(text=time.strftime("%H:%M:%S"))
    root.after(1000, update_clock)
update_clock()

# =========================
# START MENU
# =========================
start_menu = tk.Frame(desktop, bg="#222", width=220)

def toggle_start():
    if start_menu.winfo_ismapped():
        start_menu.place_forget()
    else:
        start_menu.place(x=0, y=H-40-start_menu.winfo_reqheight())

start_btn = tk.Button(
    taskbar,
    image=start_logo,
    bg="#111",
    activebackground="#111",
    relief="flat",
    command=toggle_start
)
start_btn.image = start_logo
start_btn.pack(side="left", padx=6)

# =========================
# WINDOW SYSTEM
# =========================
task_buttons = {}

def open_window(title, w=600, h=400):
    win = tk.Toplevel(root)
    win.overrideredirect(True)
    win.geometry(f"{w}x{h}+200+150")

    bar = tk.Frame(win, bg="#111", height=30)
    bar.pack(fill="x")

    tk.Label(bar, text=title, fg="white", bg="#111").pack(side="left", padx=10)

    def close():
        win.destroy()
        task_buttons[title].destroy()
        del task_buttons[title]

    tk.Button(bar, text="X", command=close).pack(side="right")

    content = tk.Frame(win, bg="#ddd")
    content.pack(fill="both", expand=True)

    btn = tk.Button(task_area, text=title, command=win.lift)
    btn.pack(side="left", padx=2)
    task_buttons[title] = btn

    return content

# =========================
# APPS
# =========================
def open_notepad(data="", path=None):
    c = open_window("Notepad")
    text = tk.Text(c)
    text.pack(fill="both", expand=True)
    if data:
        text.insert("1.0", data)

    def save():
        nonlocal path
        if not path:
            path = filedialog.asksaveasfilename(
                initialdir=FEER_FILES,
                defaultextension=".txt"
            )
        if path:
            open(path, "w", encoding="utf-8").write(text.get("1.0", "end-1c"))

    tk.Button(c, text="Save", command=save).pack()

def open_typenet(data="", path=None):
    c = open_window("TypeNet", 800, 600)

    canvas = tk.Canvas(c, bg="#aaa")
    canvas.pack(fill="both", expand=True)

    page = tk.Frame(canvas, bg="white", width=600, height=800)
    canvas.create_window((100, 20), window=page, anchor="nw")

    text = tk.Text(page, wrap="word", width=70, height=45, borderwidth=0)
    text.pack(padx=20, pady=20)

    if data:
        text.insert("1.0", data)

    def save():
        nonlocal path
        if not path:
            path = filedialog.asksaveasfilename(
                initialdir=FEER_FILES,
                defaultextension=".txt"
            )
        if path:
            open(path, "w", encoding="utf-8").write(text.get("1.0", "end-1c"))

    tk.Button(c, text="Save", command=save).pack()

def open_paint():
    c = open_window("Paint", 500, 500)
    canvas = tk.Canvas(c, bg="white", width=400, height=400)
    canvas.pack(pady=10)

    img = Image.new("RGB", (400, 400), "white")
    draw = ImageDraw.Draw(img)

    def paint(e):
        if 0 <= e.x <= 400 and 0 <= e.y <= 400:
            canvas.create_oval(e.x, e.y, e.x+4, e.y+4, fill="black")
            draw.ellipse((e.x, e.y, e.x+4, e.y+4), fill="black")

    canvas.bind("<B1-Motion>", paint)

    def save():
        img.save(os.path.join(FEER_FILES, "paint.png"))

    tk.Button(c, text="Save", command=save).pack()

def open_files():
    c = open_window("File Manager", 500, 400)
    lb = tk.Listbox(c)
    lb.pack(fill="both", expand=True)

    files = os.listdir(FEER_FILES)
    for f in files:
        lb.insert("end", f)

    def open_file(e):
        if not lb.curselection():
            return
        file = lb.get(lb.curselection()[0])
        path = os.path.join(FEER_FILES, file)

        if file.lower().endswith((".png", ".jpg", ".jpeg")):
            open_photos(path)
        else:
            open_notepad(open(path).read(), path)

    lb.bind("<Double-Button-1>", open_file)

def open_photos(path):
    c = open_window("Photos", 600, 500)
    img = Image.open(path)
    img.thumbnail((550, 450))
    photo = ImageTk.PhotoImage(img)
    lbl = tk.Label(c, image=photo)
    lbl.image = photo
    lbl.pack(expand=True)

def open_wallpaper():
    path = filedialog.askopenfilename(
        filetypes=[("Images", "*.png *.jpg *.jpeg")]
    )
    if path:
        settings["wallpaper"] = path
        save_settings()
        load_wallpaper()

def shutdown():
    root.destroy()

# =========================
# START MENU BUTTONS
# =========================
for name, cmd in [
    ("Notepad", open_notepad),
    ("TypeNet", open_typenet),
    ("Paint", open_paint),
    ("File Manager", open_files),
    ("Wallpaper", open_wallpaper),
    ("Shutdown", shutdown),
]:
    tk.Button(start_menu, text=name,
              bg="#222", fg="white",
              anchor="w", relief="flat",
              command=cmd).pack(fill="x", padx=5, pady=2)

# =========================
# START DESKTOP
# =========================
def start_desktop():
    desktop.lift()

root.mainloop()
